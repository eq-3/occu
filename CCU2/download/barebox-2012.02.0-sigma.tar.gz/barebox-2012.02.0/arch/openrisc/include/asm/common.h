#ifndef _ASM_COMMON_H
#define __ASM_COMMON_H

#endif /* _ASM_COMMON_H */
