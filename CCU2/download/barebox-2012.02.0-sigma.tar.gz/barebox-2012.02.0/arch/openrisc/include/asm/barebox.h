#ifndef _ASM_BAREBOX_H_
#define _ASM_BAREBOX_H_

#endif /* _ASM_BAREBOX_H_ */
