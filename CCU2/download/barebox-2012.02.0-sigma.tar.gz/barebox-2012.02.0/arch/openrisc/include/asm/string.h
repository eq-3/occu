#ifndef __ASM_OPENRISC_STRING_H
#define __ASM_OPENRISC_STRING_H

#endif
