#ifndef ASM_COMMON_H
#define ASM_COMMON_H

#define ARCH_HAS_CTRLC

#endif /* ASM_COMMON_H */
