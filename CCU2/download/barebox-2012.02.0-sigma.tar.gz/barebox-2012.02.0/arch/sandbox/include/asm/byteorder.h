#ifndef _I386_BYTEORDER_H
#define _I386_BYTEORDER_H

#include <asm/types.h>

#include <linux/byteorder/little_endian.h>

#endif /* _I386_BYTEORDER_H */
