#ifndef _ASM_SWAB_H
#define _ASM_SWAB_H

/* nothing. use generic functions */

#endif /* _ASM_SWAB_H */
