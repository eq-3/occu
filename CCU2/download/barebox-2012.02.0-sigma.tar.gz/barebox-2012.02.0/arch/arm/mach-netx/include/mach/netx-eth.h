#ifndef _ASM_ARCH_NETX_ETH_H
#define _ASM_ARCH_NETX_ETH_H

struct netx_eth_platform_data {
	int xcno;
};

#endif /* _ASM_ARCH_NETX_ETH_H */

