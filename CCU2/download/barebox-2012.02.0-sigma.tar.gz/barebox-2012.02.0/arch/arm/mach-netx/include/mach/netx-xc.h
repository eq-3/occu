#ifndef __ASM_ARCH_NETX_XC_H
#define __ASM_ARCH_NETX_XC_H

int loadxc(int);

#endif
