#ifndef __MACH_PXA27X_REGS
#define __MACH_PXA27X_REGS

/* this file intentionally left blank */

#endif	/* !__MACH_PXA27X_REGS */
