/*	--*- c -*--
 * Copyright (C) 2012 Enrico Scholz <enrico.scholz@sigma-chemnitz.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <common.h>
#include <errno.h>
#include <asm/io.h>
#include <mach/imx-regs.h>

#define MXS_MODULE_CLKGATE		(1u << 30)
#define MXS_MODULE_SFTRST		(1u << 31)

#define __mxs_clrl(_msk, _addr)	(__raw_writel((_msk),(_addr) + BIT_CLR))
#define __mxs_setl(_msk, _addr)	(__raw_writel((_msk),(_addr) + BIT_SET))

/*
 * Clear the bit and poll it cleared.  This is usually called with
 * a reset address and mask being either SFTRST(bit 31) or CLKGATE
 * (bit 30).
 */
static int clear_poll_bit(void __iomem *addr, u32 mask)
{
	int timeout = 0x400;

	/* clear the bit */
	__mxs_clrl(mask, addr);

	/*
	 * SFTRST needs 3 GPMI clocks to settle, the reference manual
	 * recommends to wait 1us.
	 */
	udelay(1);

	/* poll the bit becoming clear */
	while ((__raw_readl(addr) & mask) && --timeout)
		/* nothing */;

	return !timeout;
}

int mx28_reset_block(void __iomem *reset_addr, int just_enable)
{
	int ret;
	int timeout = 0x400;

	/* clear and poll SFTRST */
	ret = clear_poll_bit(reset_addr, MXS_MODULE_SFTRST);
	if (WARN_ON(ret))
		goto error;

	/* clear CLKGATE */
	__mxs_clrl(MXS_MODULE_CLKGATE, reset_addr);

	if (!just_enable) {
		/* set SFTRST to reset the block */
		__mxs_setl(MXS_MODULE_SFTRST, reset_addr);
		udelay(1);

		/* poll CLKGATE becoming set */
		while ((!(__raw_readl(reset_addr) & MXS_MODULE_CLKGATE)) && --timeout)
			udelay(1);

		if (WARN_ON(!timeout))
			goto error;
	}

	/* clear and poll SFTRST */
	ret = clear_poll_bit(reset_addr, MXS_MODULE_SFTRST);
	if (WARN_ON(ret))
		goto error;

	/* clear and poll CLKGATE */
	ret = clear_poll_bit(reset_addr, MXS_MODULE_CLKGATE);
	if (WARN_ON(ret))
		goto error;

	return 0;

error:
	pr_err("%s(%p): module reset timeout\n", __func__, reset_addr);
	return -ETIMEDOUT;
}
EXPORT_SYMBOL(mx28_reset_block);

int mx28_wait_mask_set(void __iomem *reg, uint32_t mask, int timeout)
{
	unsigned int		a = readl(0x8001c0c0);
	unsigned int		b = a;

        while ((unsigned int)(b - a) < timeout) {
                if ((readl(reg) & mask) == mask)
                        return 0;

                b = readl(0x8001c0c0);
        }

	if (0)
	printk("  to: %08x & %08x, %d / %u\n",
	       readl(reg), mask,
	       timeout, (unsigned int)(b-a));

        return -ETIMEDOUT;;
}
