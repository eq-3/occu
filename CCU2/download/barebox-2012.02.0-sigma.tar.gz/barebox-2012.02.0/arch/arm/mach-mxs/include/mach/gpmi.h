/*	--*- c -*--
 * Copyright (C) 2012 Enrico Scholz <enrico.scholz@sigma-chemnitz.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef H_BAREBOX_ARCH_ARM_MACH_MXS_GPMI_H
#define H_BAREBOX_ARCH_ARM_MACH_MXS_GPMI_H

struct mxs_nand_platform_data {
	unsigned int	ns_data_setup;
	unsigned int	ns_data_hold;
	unsigned int	ns_address_setup;
	unsigned int	ns_busy_timeout;
};

struct mxs_nand_fcb_params {
	unsigned int	timing0;
	unsigned int	timing1;
	unsigned int	page_data_size;
	unsigned int	total_page_size;
	unsigned int	pages_per_block;
	unsigned int	ecc_type[2];
	unsigned int	block_size[2];
	unsigned int	num_ecc_blocks;
	unsigned int	metadata_bytes;
	unsigned int	bad_block_bit;
};

struct mxs_nand_fcb_params const *mxs_nand_get_fcb_params(struct device_d *dev);

#endif	/* H_BAREBOX_ARCH_ARM_MACH_MXS_GPMI_H */
