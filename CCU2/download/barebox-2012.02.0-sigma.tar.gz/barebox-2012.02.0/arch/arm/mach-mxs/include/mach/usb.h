#ifndef __MACH_USB_H
#define __MACH_USB_H

int imx_usb_phy_enable(void);

#endif /* __MACH_USB_H */
