#ifndef _BAREBOX_H_
#define _BAREBOX_H_	1

#ifdef CONFIG_ARM_UNWIND
#define ARCH_HAS_STACK_DUMP
#endif

#endif	/* _BAREBOX_H_ */
