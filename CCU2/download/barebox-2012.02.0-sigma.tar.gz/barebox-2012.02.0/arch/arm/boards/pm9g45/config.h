#ifndef __CONFIG_H
#define __CONFIG_H

#define AT91_MAIN_CLOCK		12000000	/* from 12 MHz crystal */

#endif	/* __CONFIG_H */
