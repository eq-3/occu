/*	--*- c -*--
 * Copyright (C) 2011 Enrico Scholz <enrico.scholz@sigma-chemnitz.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 and/or 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <common.h>
#include <init.h>
#include <environment.h>
#include <mci.h>
#include <net.h>
#include <nand.h>
#include <partition.h>

#include <asm/io.h>
#include <asm/armlinux.h>

#include <fec.h>
#include <mach/gpio.h>
#include <mach/imx-regs.h>
#include <mach/iomux-imx28.h>
#include <mach/clock.h>
#include <mach/mci.h>
#include <mach/gpmi.h>
#include <mach/watchdog.h>

#include <generated/mach-types.h>


/* setup the CPU card internal signals */
static uint32_t const		ccu2_pad_setup[] = {
	/*
	 * Note: To setup the external phy in a manner the phy supports, its
	 * configuration is divided into a small part here at the beginning of
	 * the pad configuration and the remaining configuration at the end of
	 * these definitions.  Here: Switch on the power supply to the
	 * external phy, but keep its reset line low.
	 */
	LCD_WR_RWN_GPIO | VE_3_3V | BITKEEPER(1) | GPIO_IN, /* ENET0-INT */

	ENET_CLK    | VE_3_3V | BITKEEPER(0),

	ENET0_TX_EN | VE_3_3V | PULLUP(1),
	ENET0_MDC   | VE_3_3V | PULLUP(1),
	ENET0_MDIO  | VE_3_3V | PULLUP(0), /* external pullup */
	ENET0_TXD0  | VE_3_3V | PULLUP(1),
	ENET0_TXD1  | VE_3_3V | PULLUP(1),

	/*
	 * force the mod pins to a specific level
	 * '111' means: "All capable. Auto-negotiation enabled".
	 * For other values refer LAN8710's datasheet,
	 * chapter "Mode Bus - MODE[2:0]"
	 */
	ENET0_RXD0_GPIO  | VE_3_3V | GPIO_IN | PULLUP(1), /* MOD0 */
	ENET0_RXD1_GPIO  | VE_3_3V | GPIO_IN | PULLUP(1), /* MOD1 */
	ENET0_RX_EN_GPIO | VE_3_3V | GPIO_IN | PULLUP(1), /* MOD2 */

	/* deassert ETH0 reset */
	AUART0_CTS_GPIO  | VE_3_3V | BITKEEPER(1) | GPIO_OUT | GPIO_VALUE(1),


	/* MCI interface */
	SSP0_D0 | VE_3_3V | PULLUP(1),
	SSP0_D1 | VE_3_3V | PULLUP(1),
	SSP0_D2 | VE_3_3V | PULLUP(1),
	SSP0_D3 | VE_3_3V | PULLUP(1),
	SSP0_D4_GPIO | VE_3_3V | GPIO_IN | PULLUP(1),	/* unused */
	SSP0_D5_GPIO | VE_3_3V | GPIO_IN | PULLUP(1),	/* unused */
	SSP0_D6_GPIO | VE_3_3V | GPIO_IN | PULLUP(1),	/* unused */
	SSP0_D7_GPIO | VE_3_3V | GPIO_IN | PULLUP(1),	/* unused */
	SSP0_CMD | VE_3_3V | PULLUP(1),
	SSP0_SCK | VE_3_3V | BITKEEPER(1),
	PWM3_GPIO | VE_3_3V | GPIO_OUT | GPIO_VALUE(1),	/* SD-PWR-EN */

	/* SPI interface to Atmel IC; keep signals floating because both the
	 * mx28 and the avr can be SPI masters */
	SSP2_SCK_GPIO | GPIO_IN | VE_3_3V | BITKEEPER(0),
	SSP2_MOSI_GPIO | GPIO_IN | VE_3_3V | PULLUP(0),
	SSP2_MISO_GPIO | GPIO_IN | VE_3_3V | PULLUP(0),

	SSP2_SS0_GPIO | VE_3_3V | PULLUP(0),
	SSP2_SS1_GPIO | VE_3_3V | PULLUP(0),
	SSP2_SS2_GPIO | GPIO_OUT | GPIO_VALUE(0) | VE_3_3V | PULLUP(1),

	/* I2C interface */
	I2C0_SCL | VE_3_3V | BITKEEPER(1),
	I2C0_SDA | VE_3_3V | BITKEEPER(1),

	/* AUART0 */
	AUART0_RX | VE_3_3V | BITKEEPER(1),
	AUART0_TX | VE_3_3V | BITKEEPER(1),

	/* AUART1 */
	AUART1_RX | VE_3_3V | PULLUP(1),
	AUART1_TX | VE_3_3V | PULLUP(1),

	/* KEY/LED */
	SAIF0_BITCLK_GPIO | VE_3_3V | GPIO_IN, /* KEY */
	SAIF0_LRCLK_GPIO | VE_3_3V | GPIO_OUT | GPIO_VALUE(1),	/* LED-1 */
	SAIF0_MCLK_GPIO | VE_3_3V | GPIO_OUT | GPIO_VALUE(1),	/* LED-0 */
	SAIF0_SDATA0_GPIO | VE_3_3V | GPIO_OUT | GPIO_VALUE(1), /* LED-2 */

	/* DUART */
	PWM0_DUART_RX | VE_3_3V | BITKEEPER(1),
	PWM1_DUART_TX | VE_3_3V | BITKEEPER(1),

	/* MP */
	SAIF1_SDATA0_GPIO | VE_3_3V | GPIO_OUT | BITKEEPER(1),	/* MP111 */
	PWM2_GPIO | VE_3_3V | GPIO_OUT | PULLUP(1),		/* MP304 */
	PWM4_GPIO | VE_3_3V | GPIO_OUT | BITKEEPER(1),		/* MP305 */
	GPMI_CE1N_GPIO | VE_3_3V | GPIO_IN | PULLUP(1),		/* MP302 */
	GPMI_READY1_GPIO | VE_3_3V | GPIO_IN | PULLUP(1),	/* MP303 */

	/* USB */
	LCD_RD_E_GPIO | VE_3_3V | GPIO_OUT | GPIO_VALUE(0),  /* USB1-EN */
	AUART0_RTS_GPIO | VE_3_3V | GPIO_IN | GPIO_VALUE(1), /* USB0-EN */

	/* GPMI */
	GPMI_ALE | VE_3_3V | PULLUP(0),
	GPMI_CE0N | VE_3_3V | PULLUP(0),
	GPMI_CLE | VE_3_3V | PULLUP(0),
	GPMI_RDN | VE_3_3V | PULLUP(0),
	GPMI_READY0 | VE_3_3V | PULLUP(0),
	GPMI_WRN | VE_3_3V | PULLUP(0),
	GPMI_D0 |  VE_3_3V | PULLUP(0),
	GPMI_D1 |  VE_3_3V | PULLUP(0),
	GPMI_D2 |  VE_3_3V | PULLUP(0),
	GPMI_D3 |  VE_3_3V | PULLUP(0),
	GPMI_D4 |  VE_3_3V | PULLUP(0),
	GPMI_D5 |  VE_3_3V | PULLUP(0),
	GPMI_D6 |  VE_3_3V | PULLUP(0),
	GPMI_D7 |  VE_3_3V | PULLUP(0),

	GPMI_RESETN | VE_3_3V | PULLUP(0),
};

/* setup the CPU card internal signals */
static uint32_t const		ccu2_pad_late_setup[] = {
	/* ethernet initialization; part 2 */

	/* release the reset ('mod' pins get latched) */
	AUART0_CTS_GPIO | VE_3_3V | BITKEEPER(1) | GPIO_OUT | GPIO_VALUE(1),

	/* right now the 'mod' pins are in their native mode */
	ENET0_RXD0  | VE_3_3V | PULLUP(0),
	ENET0_RXD1  | VE_3_3V | PULLUP(0),
	ENET0_RX_EN | VE_3_3V | PULLUP(0),
};

static int ccu2_mem_init(void)
{
	arm_add_mem_device("ram0", IMX_MEMORY_BASE, 256 * 1024 * 1024);

	return 0;
}
mem_initcall(ccu2_mem_init);

static uint64_t	board_sernum;

static void ccu2_set_ethaddr_factory(uint32_t const ocotp[4])
{
	if (ocotp[0] != 0 && ocotp[0] != 0xbadabada &&
	    ocotp[1] != 0 && ocotp[1] != 0xbadabada) {
		unsigned char	mac[6] = {
			[0] = (ocotp[0] >> 24) & 0xffu,
			[1] = (ocotp[0] >> 16) & 0xffu,
			[2] = (ocotp[0] >>  8) & 0xffu,
			[3] = (ocotp[0] >>  0) & 0xffu,
			[4] = (ocotp[1] >> 24) & 0xffu,
			[5] = (ocotp[1] >> 16) & 0xffu,
		};

		eth_register_ethaddr(0, mac);
	} else if (board_sernum != 0 &&
		   board_sernum != 0xbadabadabadabadaULL) {
		unsigned char	mac[6] = {
			[0] = 0x02,
			[1] = (unsigned int)(board_sernum >> 32) & 0xffu,
			[2] = (unsigned int)(board_sernum >> 24) & 0xffu,
			[3] = (unsigned int)(board_sernum >> 16) & 0xffu,
			[4] = (unsigned int)(board_sernum >>  8) & 0xffu,
			[5] = (unsigned int)(board_sernum >>  0) & 0xffu,
		};

		eth_register_ethaddr(0, mac);
	}
}

static void ccu2_set_eq3_id(char *id_str, uint32_t const ocotp[4])
{
	size_t		i;

	id_str[0] = (ocotp[1] >>  8) & 0xffu;
	id_str[1] = (ocotp[1] >>  0) & 0xffu;
	id_str[2] = (ocotp[2] >> 24) & 0xffu;
	id_str[3] = (ocotp[2] >> 16) & 0xffu;
	id_str[4] = (ocotp[2] >>  8) & 0xffu;
	id_str[5] = (ocotp[2] >>  0) & 0xffu;
	id_str[6] = (ocotp[3] >> 24) & 0xffu;
	id_str[7] = (ocotp[3] >> 16) & 0xffu;
	id_str[8] = (ocotp[3] >>  8) & 0xffu;
	id_str[9] = (ocotp[3] >>  0) & 0xffu;

	for (i = 0; i < 10; ++i) {
		if (id_str[i] < 32 || id_str[i] > 127) {
			id_str[0] = '\0';
			return;
		}
	}
}

static struct mxs_mci_platform_data mci0_pdata = {
	.caps = MMC_MODE_4BIT,
	.voltages = MMC_VDD_32_33 | MMC_VDD_33_34,	/* fixed to 3.3 V */
	.f_min = 400 * 1000,
	.f_max = 25000000,
};

/* PhyAD[0..2]=0, RMIISEL=1 */
static struct fec_platform_data fec_info = {
	.xcv_type = RMII,
	.phy_addr = 0,
};

struct mxs_nand_platform_data const	nand_info = {
	.ns_data_setup = 25,
	.ns_data_hold = 15,
	.ns_address_setup = 150,
	.ns_busy_timeout = 700000,
};

static int ccu2_core_init(void)
{
	int 		i;

	/* initizalize gpios */
	for (i = 0; i < ARRAY_SIZE(ccu2_pad_setup); i++)
		imx_gpio_mode(ccu2_pad_setup[i]);

	watchdog_prepare();
	watchdog_trigger(5000);

	return 0;
}
core_initcall(ccu2_core_init);

static int ccu2_console_init(void)
{
	if (1)
	add_generic_device("stm_serial", 0, NULL, IMX_DBGUART_BASE, 8192,
			   IORESOURCE_MEM, NULL);

	if (0)
	add_generic_device("imxapp_serial", 0, NULL, IMX_UART0_BASE, 0x100,
			   IORESOURCE_MEM, NULL);

	return 0;
}
console_initcall(ccu2_console_init);

static int ccu2_devices_init(void)
{
	int 		i;
	uint32_t	ocotp_cust[4];
	char		eq3_id[12] = { [10] = ' ', [11] = '\0' };
	unsigned int	loops;

	writel((1u << 12), 0x8002c004);	/* HW_OCOTP_CTRL |= RD_BANK_OPEN */

	/* enable IOCLK0 to run at the PLL frequency */
	imx_set_ioclk(0, 480000000);
	/* run the SSP unit clock at 100 MHz */
	imx_set_sspclk(0, 100000000, 1);
	/* run the SSP unit clock at 100 MHz */
	imx_set_sspclk(1, 100000000, 1);

	imx_set_gpmiclk(60000000, 0);

	imx_enable_enetclk();

	/* {{{ slot for releasing J301 */
	udelay(500000);
	watchdog_prepare();
	watchdog_trigger(5000);
	/* }}} */

	armlinux_set_bootparams((void *)IMX_MEMORY_BASE + 0x100);
	armlinux_set_architecture(MACH_TYPE_ELV_CCU2);

	/* delay access to OCOTP */
	while (readl(0x8002c000) & (1u << 8))
		;			/* noop */

	ocotp_cust[0]  = readl(0x8002c020);
	ocotp_cust[1]  = readl(0x8002c030);
	ocotp_cust[2]  = readl(0x8002c040);
	ocotp_cust[3]  = readl(0x8002c050);

	/* \todo: do this? do we reveal secrets? */
	/* \todo: fixme! manual says, UN2 is hi-word but this seems to be
	 * equal to OPS3 */
	board_sernum   = readl(0x8002c160);	/* HW_OCOTP_OPS3 */
	board_sernum <<= 32;
	board_sernum  |= readl(0x8002c150);	/* HW_OCOTP_OPS2 */

	writel((1u << 12), 0x8002c008);	/* HW_OCOTP_CTRL &= ~RD_BANK_OPEN */

	armlinux_set_serial(board_sernum);
	ccu2_set_ethaddr_factory(ocotp_cust);
	ccu2_set_eq3_id(eq3_id, ocotp_cust);

	/* ensure that pins are driven for t_csh = 1ns but not more than
	 * t_odad = 800ns */
	gpio_set_value(3*32 + 2, 0);	/* ENET-nRST */
	udelay(10000);
	gpio_set_value(3*32 + 2, 1);	/* ENET-nRST */

	/* initizalize gpios */
	for (i = 0; i < ARRAY_SIZE(ccu2_pad_late_setup); i++)
		imx_gpio_mode(ccu2_pad_late_setup[i]);

	/* create devices */

	add_generic_device("mxs_mci", 0, NULL, IMX_SSP0_BASE, 0x2000,
			   IORESOURCE_MEM, &mci0_pdata);

	add_generic_device("fec_imx", 0, NULL, IMX_FEC0_BASE, 0x4000,
			   IORESOURCE_MEM, &fec_info);

	add_generic_device("mxs_nand", 0, NULL, 0, 0, IORESOURCE_MEM,
			   (void *)&nand_info);

	imx_dump_clocks();

	printf("Board serial: %s(%08x:%08x); boot flags %02x\n",
	       eq3_id,
	       (unsigned int)(board_sernum >> 32),
	       (unsigned int)(board_sernum >>  0),
	       readl(0x80056070) & 0xffu);

	return 0;
}
device_initcall(ccu2_devices_init);

static struct {
	size_t		size;
	char const	*name;
	char const	*bb_name;
} const		PARTITIONS[] = {
	{      1024 * 1024, NULL, NULL }, /* FCB */
	{      1024 * 1024, NULL, NULL }, /* BBT */
	{      1024 * 1024, "env0_raw",    "env0" },
	{      1536 * 1024, "bootstream0", "bootstream0.bb" },
	{ 6 * 1024 * 1024, "bootstream1", "bootstream1.bb" },
};

static int ccu2_late_init(void)
{
	size_t		offset = 0;
	size_t		i;
	int		rc = 0;
	unsigned int	ctrl_usb = readl(0x80080140);

	/* disconnect USB client */
	if (ctrl_usb & (1u << 0)) {
		writel(ctrl_usb & ~(1u << 0), 0x80080140);
		while (readl(0x80080140) & (1u << 0))
			;		/* noop */
		writel((ctrl_usb & ~(1u << 0)) | (1u << 1), 0x80080140);
	}

	for (i = 0; i < ARRAY_SIZE(PARTITIONS); ++i) {
		BUG_ON(!PARTITIONS[i].name && PARTITIONS[i].bb_name);

		if (PARTITIONS[i].name) {
			rc = devfs_add_partition("nand0", offset,
						 PARTITIONS[i].size,
						 PARTITION_FIXED,
						 PARTITIONS[i].name);
			if (rc < 0)
				printk(KERN_ERR
				       "failed to add partition '%s': %d\n",
				       PARTITIONS[i].name, rc);
		}

		if (PARTITIONS[i].bb_name && !rc) {

			rc = dev_add_bb_dev(PARTITIONS[i].name,
					    PARTITIONS[i].bb_name);

			if (rc < 0)
				printk(KERN_ERR
				       "failed to add bb partition '%s': %d\n",
				       PARTITIONS[i].bb_name, rc);
		}

		if (rc < 0)
			break;

		offset += PARTITIONS[i].size;
	}

	return rc;
}
late_initcall(ccu2_late_init);
