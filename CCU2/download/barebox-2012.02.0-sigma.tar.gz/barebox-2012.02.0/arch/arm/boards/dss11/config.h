#ifndef __CONFIG_H
#define __CONFIG_H

#define AT91_MAIN_CLOCK		18432000	/* 18.432 MHz crystal */

#endif	/* __CONFIG_H */
