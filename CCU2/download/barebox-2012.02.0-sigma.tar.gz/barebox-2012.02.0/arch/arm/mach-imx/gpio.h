
extern void *imx_gpio_base[];
extern int imx_gpio_count;

