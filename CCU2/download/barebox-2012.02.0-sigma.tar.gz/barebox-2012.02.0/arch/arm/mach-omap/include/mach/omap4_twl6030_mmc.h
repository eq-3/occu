/*
 * Copyright (C) 2011 Alexander Aring <a.aring@phytec.de>
 */

#ifndef __OMAP4_TWL6030_MMC_H__
#define __OMAP4_TWL6030_MMC_H__

/*
 * Sets up voltage for mmc slot.
 */
void set_up_mmc_voltage_omap4(void);

/* __OMAP4_TWL6030_MMC_H__ */
#endif
